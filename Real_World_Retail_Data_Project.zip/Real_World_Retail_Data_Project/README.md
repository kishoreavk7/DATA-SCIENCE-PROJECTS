# Retail Sales Analysis Project

## Run the project
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python retail_analysis.py`
5. Open `outputs/` to view charts and exported analysis tables.

## Dataset
`data/retail_sales.csv` contains 500 simulated orders. It is intended for education and is not verified real company data.

## Main project features
- Data overview and missing-value checks
- Business KPIs: revenue, profit, average order revenue, profit margin
- Category, city, monthly and channel analysis
- Visualizations and structured report
