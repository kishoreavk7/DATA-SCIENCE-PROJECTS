# Real-World Data Project: Retail Sales Analysis

## 1. Objective
Analyze retail sales transactions to understand revenue, profit, product-category performance, city performance, monthly trends, and sales-channel differences.

## 2. Dataset
The project includes 500 simulated retail orders from 2025. It contains order date, city, sales channel, product, category, unit price, quantity, discount, revenue, cost, and profit.

**Important:** This is an educational simulated dataset, not confidential or verified real business data.

## 3. Tools
- Python
- pandas for data preparation and aggregation
- matplotlib for visualizations
- CSV for data storage and result exports

## 4. Methodology
1. Load the sales CSV file and parse dates.
2. Check dataset shape, data types, and missing values.
3. Calculate total revenue, profit, average order revenue, and profit margin.
4. Compare product categories and cities.
5. Explore monthly revenue and sales channels.
6. Export summary tables and charts.

## 5. Key findings from the included sample
- Total orders: 500
- Total revenue: ₹366,639.25
- Total profit: ₹134,181.25
- Average order revenue: ₹733.28
- Overall profit margin: 36.60%
- Highest-revenue category: Electronics
- Highest-profit city: Coimbatore
- Highest-revenue channel: Online

## 6. Business recommendations
- Keep sufficient stock for categories generating the most revenue.
- Review low-profit products and discount levels before increasing promotions.
- Compare city performance with marketing spend and stock availability before reallocating resources.
- Monitor monthly revenue trends to support inventory and staffing plans.
- Compare online and in-store performance using both profit and revenue, not revenue alone.

## 7. Conclusion
This project demonstrates an end-to-end applied data analysis workflow, from dataset preparation and KPI calculation to visual exploration and business recommendations. Replace the sample CSV with an authorized real retail dataset to apply the workflow to an actual business.

## 8. Files produced
- `business_kpis.csv`
- `category_performance.csv`
- `city_performance.csv`
- `monthly_performance.csv`
- `revenue_by_category.png`
- `monthly_revenue.png`
- `profit_by_city.png`
- `revenue_by_channel.png`

## 9. Limitations
The data is simulated, the period is limited to one year, and the findings are descriptive rather than predictive. Correlation or performance differences alone do not prove causation.
