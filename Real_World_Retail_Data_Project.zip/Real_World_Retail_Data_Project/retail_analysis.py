"""
Real-World Data Project: Retail Sales Analysis
Dataset is simulated for educational use, with realistic fields.
Run:
    pip install -r requirements.txt
    python retail_analysis.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "retail_sales.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["date"])

# 1. Basic checks
print("=== DATA OVERVIEW ===")
print(df.head())
print("\nRows and columns:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nSummary statistics:\n", df.describe(include="all").to_string())

# 2. Business KPIs
total_revenue = df["revenue_inr"].sum()
total_profit = df["profit_inr"].sum()
total_orders = df["order_id"].nunique()
avg_order_value = df["revenue_inr"].mean()
profit_margin = (total_profit / total_revenue * 100) if total_revenue else 0

kpis = pd.DataFrame([
    ["Total orders", total_orders],
    ["Total revenue (INR)", round(total_revenue, 2)],
    ["Total profit (INR)", round(total_profit, 2)],
    ["Average order revenue (INR)", round(avg_order_value, 2)],
    ["Profit margin (%)", round(profit_margin, 2)]
], columns=["metric", "value"])
kpis.to_csv(OUT / "business_kpis.csv", index=False)

# 3. Aggregated analysis
df.groupby("category", as_index=False).agg(
    orders=("order_id", "count"),
    revenue_inr=("revenue_inr", "sum"),
    profit_inr=("profit_inr", "sum")
).sort_values("revenue_inr", ascending=False).to_csv(OUT / "category_performance.csv", index=False)

df.groupby("city", as_index=False).agg(
    orders=("order_id", "count"),
    revenue_inr=("revenue_inr", "sum"),
    profit_inr=("profit_inr", "sum")
).sort_values("revenue_inr", ascending=False).to_csv(OUT / "city_performance.csv", index=False)

monthly = df.groupby(df["date"].dt.to_period("M")).agg(
    revenue_inr=("revenue_inr", "sum"),
    profit_inr=("profit_inr", "sum")
).reset_index()
monthly["date"] = monthly["date"].astype(str)
monthly.to_csv(OUT / "monthly_performance.csv", index=False)

# 4. Visualizations
category = df.groupby("category")["revenue_inr"].sum().sort_values(ascending=False)
plt.figure(figsize=(8,5))
plt.bar(category.index, category.values)
plt.title("Revenue by Product Category")
plt.xlabel("Category")
plt.ylabel("Revenue (INR)")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT / "revenue_by_category.png", dpi=150)
plt.close()

monthly_plot = df.groupby(df["date"].dt.to_period("M"))["revenue_inr"].sum()
plt.figure(figsize=(9,5))
plt.plot(monthly_plot.index.astype(str), monthly_plot.values, marker="o")
plt.title("Monthly Retail Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue (INR)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUT / "monthly_revenue.png", dpi=150)
plt.close()

city = df.groupby("city")["profit_inr"].sum().sort_values(ascending=False)
plt.figure(figsize=(8,5))
plt.bar(city.index, city.values)
plt.title("Profit by City")
plt.xlabel("City")
plt.ylabel("Profit (INR)")
plt.tight_layout()
plt.savefig(OUT / "profit_by_city.png", dpi=150)
plt.close()

channel = df.groupby("channel")["revenue_inr"].sum()
plt.figure(figsize=(6,5))
plt.bar(channel.index, channel.values)
plt.title("Revenue by Sales Channel")
plt.xlabel("Channel")
plt.ylabel("Revenue (INR)")
plt.tight_layout()
plt.savefig(OUT / "revenue_by_channel.png", dpi=150)
plt.close()

print("\nAnalysis complete. Check the outputs folder for tables and charts.")
