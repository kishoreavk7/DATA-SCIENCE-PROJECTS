"""
Exploratory Data Analysis (EDA) Project
Dataset: sample student performance data
Run: python eda_analysis.py
Install dependencies: pip install pandas matplotlib seaborn
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "student_performance.csv"
OUT_DIR = ROOT / "outputs"
OUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_FILE)

print("\n=== DATASET OVERVIEW ===")
print(df.head())
print("\nShape:", df.shape)
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isnull().sum())
print("\nStatistical summary:\n", df.describe().round(2))

# Save statistical summaries and correlations
df.describe().round(2).to_csv(OUT_DIR / "statistical_summary.csv")
df.corr(numeric_only=True).round(3).to_csv(OUT_DIR / "correlation_matrix.csv")

sns.set_theme(style="whitegrid")

plt.figure(figsize=(8, 5))
sns.histplot(df["exam_score"], bins=15, kde=True)
plt.title("Distribution of Exam Scores")
plt.xlabel("Exam score")
plt.tight_layout()
plt.savefig(OUT_DIR / "exam_score_distribution.png", dpi=150)
plt.close()

plt.figure(figsize=(8, 5))
sns.regplot(data=df, x="study_hours_per_day", y="exam_score",
            scatter_kws={"alpha": 0.65})
plt.title("Study Hours vs Exam Score")
plt.tight_layout()
plt.savefig(OUT_DIR / "study_hours_vs_score.png", dpi=150)
plt.close()

plt.figure(figsize=(8, 5))
sns.regplot(data=df, x="attendance_percent", y="exam_score",
            scatter_kws={"alpha": 0.65})
plt.title("Attendance vs Exam Score")
plt.tight_layout()
plt.savefig(OUT_DIR / "attendance_vs_score.png", dpi=150)
plt.close()

plt.figure(figsize=(7, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm",
            fmt=".2f", vmin=-1, vmax=1)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(OUT_DIR / "correlation_heatmap.png", dpi=150)
plt.close()

print(f"\nEDA complete. Outputs saved to: {OUT_DIR}")
