# Exploratory Data Analysis (EDA) Project

## Project overview
This beginner-friendly project explores a sample student-performance dataset to identify patterns between study hours, attendance, sleep, and exam scores.

## Folder structure
- `data/student_performance.csv` — sample dataset (200 records)
- `eda_analysis.py` — Python EDA script
- `requirements.txt` — required Python packages
- `report.md` — structured project report
- `outputs/` — generated charts and statistical CSV files after running the script

## How to run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python eda_analysis.py
   ```
5. Check the `outputs` folder for plots and CSV summaries.

## Note
The dataset is synthetic sample data created for learning. Findings describe this sample only and should not be treated as evidence about real students.
