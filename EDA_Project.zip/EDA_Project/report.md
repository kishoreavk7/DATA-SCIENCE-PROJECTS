# Exploratory Data Analysis (EDA) Report
## 1. Title
Exploratory Data Analysis of Student Performance

## 2. Objective
To explore a dataset using statistical summaries and visualizations, identify relationships among variables, and communicate the main findings in a structured report.

## 3. Dataset
The project uses a synthetic educational dataset containing 200 records and these columns:
- `student_id`: unique row identifier
- `study_hours_per_day`: average daily study time
- `attendance_percent`: attendance percentage
- `sleep_hours`: average sleep duration
- `exam_score`: exam score from 0 to 100

## 4. Methodology
1. Load the CSV dataset using pandas.
2. Inspect rows, shape, data types, and missing values.
3. Calculate descriptive statistics with `describe()`.
4. Calculate Pearson correlations between numeric variables.
5. Create a score-distribution plot, scatter/regression plots, and a correlation heatmap.
6. Save the figures and summary tables in `outputs/`.

## 5. Questions explored
- What is the distribution of exam scores?
- Is study time associated with exam score?
- Is attendance associated with exam score?
- Which numeric variables have stronger linear relationships in this sample?

## 6. Expected interpretation
Because this is synthetic sample data, the analysis is intended to demonstrate the EDA workflow. The generated correlation matrix and plots should be consulted for the exact values after running the script. A positive correlation indicates that two variables tend to increase together; it does not prove that one causes the other.

## 7. Conclusion
This project demonstrates a complete beginner-level EDA workflow: data inspection, cleaning checks, descriptive statistics, correlation analysis, visualization, and reporting. The same workflow can be adapted to a real dataset by replacing the CSV file and updating the variable names.

## 8. Limitations
- The data is synthetic and may not represent real-world student behavior.
- Correlation does not establish causation.
- The dataset contains only 200 records and a small number of variables.

## 9. Sample results
- Number of records: 200
- Average exam score: 74.36
- Average daily study time: 4.23 hours
- Correlation between study hours and exam score: 0.87
- Correlation between attendance and exam score: 0.36

These are computed from the included synthetic dataset. Treat them as demonstration results, not conclusions about real students.
