"""Run the complete data cleaning, analysis, and chart generation workflow."""
from src.data_cleaning import clean_data
from src.eda import analyze_data
from src.visualizations import create_charts

def main():
    print("Step 1/3: Cleaning raw data...")
    clean_data()
    print("Step 2/3: Performing exploratory data analysis...")
    summary = analyze_data()
    print("Step 3/3: Creating visualizations...")
    charts = create_charts()
    print("\\nPROJECT COMPLETED")
    print(f"Total sales: {summary['total_sales']:,.2f}")
    print(f"Total orders: {summary['total_orders']:,}")
    print(f"Charts generated: {len(charts)}")

if __name__ == "__main__":
    main()
