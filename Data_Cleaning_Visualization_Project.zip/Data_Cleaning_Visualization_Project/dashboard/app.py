"""Interactive Streamlit dashboard for retail sales analysis."""
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "cleaned_sales_data.csv"

st.set_page_config(page_title="Retail Sales Analytics", page_icon="📊", layout="wide")
st.title("📊 Retail Sales Cleaning & Visualization Dashboard")
st.caption("Explore cleaned retail sales data, customer patterns, and business performance.")

if not DATA_PATH.exists():
    st.error("Cleaned dataset not found. Run `python main.py` from the project root first.")
    st.stop()

df = pd.read_csv(DATA_PATH, parse_dates=["Order Date"])
with st.sidebar:
    st.header("Filters")
    categories = st.multiselect("Product category", sorted(df["Product Category"].unique()),
                                default=sorted(df["Product Category"].unique()))
    cities = st.multiselect("City", sorted(df["City"].unique()), default=sorted(df["City"].unique()))
    date_min, date_max = df["Order Date"].min().date(), df["Order Date"].max().date()
    date_range = st.date_input("Order date range", value=(date_min, date_max),
                               min_value=date_min, max_value=date_max)

filtered = df[df["Product Category"].isin(categories) & df["City"].isin(cities)].copy()
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    filtered = filtered[filtered["Order Date"].dt.date.between(date_range[0], date_range[1])]

if filtered.empty:
    st.warning("No records match the selected filters.")
    st.stop()

sales = filtered["Total Sales"].sum()
orders = filtered["Order ID"].nunique()
aov = sales / orders if orders else 0
c1, c2, c3 = st.columns(3)
c1.metric("Total Sales", f"₹{sales:,.0f}")
c2.metric("Total Orders", f"{orders:,}")
c3.metric("Average Order Value", f"₹{aov:,.0f}")

left, right = st.columns(2)
with left:
    cat = filtered.groupby("Product Category", as_index=False)["Total Sales"].sum()
    st.plotly_chart(px.bar(cat, x="Product Category", y="Total Sales",
                           title="Sales by Product Category", color="Product Category"), use_container_width=True)
with right:
    monthly = filtered.assign(Month=filtered["Order Date"].dt.to_period("M").astype(str)).groupby("Month", as_index=False)["Total Sales"].sum()
    st.plotly_chart(px.line(monthly, x="Month", y="Total Sales", markers=True,
                            title="Monthly Sales Trend"), use_container_width=True)

left, right = st.columns(2)
with left:
    city = filtered.groupby("City", as_index=False)["Total Sales"].sum().sort_values("Total Sales", ascending=False)
    st.plotly_chart(px.bar(city, x="City", y="Total Sales", title="City-wise Sales"), use_container_width=True)
with right:
    pay = filtered["Payment Method"].value_counts().rename_axis("Payment Method").reset_index(name="Orders")
    st.plotly_chart(px.pie(pay, names="Payment Method", values="Orders",
                           title="Payment Method Distribution"), use_container_width=True)

st.subheader("Top 10 Products")
top = filtered.groupby("Product Name", as_index=False)["Quantity"].sum().nlargest(10, "Quantity")
st.dataframe(top, use_container_width=True, hide_index=True)

st.subheader("Filtered Data")
st.dataframe(filtered, use_container_width=True, hide_index=True)
st.download_button("⬇️ Download Cleaned CSV", filtered.to_csv(index=False).encode("utf-8"),
                   file_name="cleaned_retail_sales.csv", mime="text/csv")
