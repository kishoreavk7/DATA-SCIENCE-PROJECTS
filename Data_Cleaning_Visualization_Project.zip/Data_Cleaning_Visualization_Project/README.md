# Data Cleaning & Visualization Project

A beginner-friendly Python project that cleans a deliberately imperfect retail sales dataset, performs exploratory data analysis (EDA), creates charts, and provides an interactive Streamlit dashboard.

## Features
- Missing-value identification and imputation
- Duplicate removal
- Invalid value handling and outlier-aware validation
- Data type correction and text standardization
- Sales KPIs and category/city/monthly analysis
- PNG charts generated with Matplotlib and Seaborn
- Interactive Streamlit dashboard with filters and CSV download

## Technology Stack
Python, Pandas, NumPy, Matplotlib, Seaborn, Streamlit, Plotly.

## Project Structure
```text
data-cleaning-visualization/
├── data/
│   ├── raw_sales_data.csv
│   └── cleaned_sales_data.csv
├── src/
│   ├── data_cleaning.py
│   ├── eda.py
│   └── visualizations.py
├── dashboard/
│   └── app.py
├── output/
│   ├── charts/
│   └── reports/
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Setup
Open this folder in VS Code. Create/activate a virtual environment if desired, then install dependencies:

```bash
pip install -r requirements.txt
```

## Run the complete workflow
From the project root:

```bash
python main.py
```

This cleans the raw CSV, writes the cleaned CSV, creates text reports, and generates charts in `output/charts/`.

## Run the dashboard
```bash
streamlit run dashboard/app.py
```

The dashboard includes sales KPIs, category and city analysis, monthly trends, payment distribution, filters, and a cleaned CSV download.

## Data Cleaning Methodology
- Duplicate rows are removed.
- Text values are trimmed and standardized.
- Dates and numeric fields are converted to suitable types.
- Ages outside 18–100 and non-positive quantities/prices are treated as invalid.
- Missing numeric values are filled using the median; missing categorical values use the mode.
- Total Sales is recalculated as Quantity × Unit Price to keep the dataset consistent.

## Key Analysis
The scripts calculate total sales, order count, average order value, category sales, city sales, monthly sales, and top products. Exact results are generated from the included dataset and saved in `output/reports/`.

## Notes
The included dataset is synthetic and intended for learning and portfolio demonstration. It does not contain real customer information.
