"""Create PNG charts from the cleaned retail sales dataset."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "cleaned_sales_data.csv"
CHART_DIR = ROOT / "output" / "charts"

def create_charts(path=DATA_PATH):
    CHART_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(path, parse_dates=["Order Date"])
    sns.set_theme(style="whitegrid")

    def save(name):
        plt.tight_layout()
        plt.savefig(CHART_DIR / name, dpi=150, bbox_inches="tight")
        plt.close()

    plt.figure(figsize=(9, 5))
    df.groupby("Product Category")["Total Sales"].sum().sort_values().plot(kind="barh")
    plt.title("Sales by Product Category"); plt.xlabel("Sales")
    save("sales_by_category.png")

    monthly = df.set_index("Order Date").resample("ME")["Total Sales"].sum()
    plt.figure(figsize=(10, 5)); monthly.plot(marker="o")
    plt.title("Monthly Sales Trend"); plt.ylabel("Sales"); plt.xlabel("Month")
    save("monthly_sales_trend.png")

    plt.figure(figsize=(9, 5))
    df.groupby("City")["Total Sales"].sum().sort_values().plot(kind="bar")
    plt.title("City-wise Sales"); plt.ylabel("Sales"); plt.xticks(rotation=35)
    save("city_wise_sales.png")

    plt.figure(figsize=(7, 5))
    df["Gender"].value_counts().plot(kind="pie", autopct="%1.1f%%", startangle=90)
    plt.title("Customer Gender Distribution"); plt.ylabel("")
    save("gender_distribution.png")

    plt.figure(figsize=(8, 5))
    df["Payment Method"].value_counts().plot(kind="bar")
    plt.title("Payment Method Distribution"); plt.xticks(rotation=25)
    save("payment_method_distribution.png")

    top = df.groupby("Product Name")["Quantity"].sum().nlargest(10).sort_values()
    plt.figure(figsize=(9, 6)); top.plot(kind="barh")
    plt.title("Top 10 Products by Quantity"); plt.xlabel("Quantity")
    save("top_10_products.png")

    plt.figure(figsize=(8, 5))
    df["Age"].plot(kind="hist", bins=15, edgecolor="black")
    plt.title("Customer Age Distribution"); plt.xlabel("Age")
    save("age_distribution.png")

    plt.figure(figsize=(8, 6))
    sns.heatmap(df[["Age", "Quantity", "Unit Price", "Total Sales"]].corr(),
                annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Numeric Feature Correlation")
    save("correlation_heatmap.png")

    return sorted(p.name for p in CHART_DIR.glob("*.png"))

if __name__ == "__main__":
    print("Created charts:", create_charts())
