"""Generate summary statistics and key retail sales insights."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "cleaned_sales_data.csv"
REPORT_PATH = ROOT / "output" / "reports" / "eda_summary.txt"

def analyze_data(path=DATA_PATH):
    df = pd.read_csv(path, parse_dates=["Order Date"])
    total_sales = df["Total Sales"].sum()
    total_orders = df["Order ID"].nunique()
    avg_order_value = total_sales / total_orders if total_orders else 0
    category = df.groupby("Product Category")["Total Sales"].sum().sort_values(ascending=False)
    city = df.groupby("City")["Total Sales"].sum().sort_values(ascending=False)
    monthly = df.assign(Month=df["Order Date"].dt.to_period("M").astype(str)).groupby("Month")["Total Sales"].sum()
    top_products = df.groupby("Product Name")["Quantity"].sum().sort_values(ascending=False).head(10)
    lines = [
        "RETAIL SALES EDA SUMMARY",
        "=======================",
        f"Total sales: {total_sales:,.2f}",
        f"Total orders: {total_orders:,}",
        f"Average order value: {avg_order_value:,.2f}",
        f"Best category: {category.index[0]} ({category.iloc[0]:,.2f})",
        f"Top city: {city.index[0]} ({city.iloc[0]:,.2f})",
        "",
        "Sales by category:",
        category.to_string(),
        "",
        "Sales by city:",
        city.to_string(),
        "",
        "Top 10 products by quantity:",
        top_products.to_string(),
        "",
        "Monthly sales:",
        monthly.to_string()
    ]
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\\n".join(lines), encoding="utf-8")
    return {"total_sales": total_sales, "total_orders": total_orders,
            "average_order_value": avg_order_value, "category_sales": category,
            "city_sales": city, "monthly_sales": monthly, "top_products": top_products}

if __name__ == "__main__":
    result = analyze_data()
    print(f"Total sales: {result['total_sales']:,.2f}")
    print(f"Total orders: {result['total_orders']:,}")
    print(f"Average order value: {result['average_order_value']:,.2f}")
