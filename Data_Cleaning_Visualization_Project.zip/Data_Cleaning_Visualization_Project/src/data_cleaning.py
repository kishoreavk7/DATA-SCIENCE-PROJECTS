"""Clean the raw retail sales dataset and save a validated CSV."""
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw_sales_data.csv"
CLEAN_PATH = ROOT / "data" / "cleaned_sales_data.csv"
REPORT_PATH = ROOT / "output" / "reports" / "data_quality_report.txt"

def clean_data(input_path=RAW_PATH, output_path=CLEAN_PATH):
    df = pd.read_csv(input_path)
    original_rows = len(df)
    missing_before = int(df.isna().sum().sum())
    duplicates_removed = int(df.duplicated().sum())
    df = df.drop_duplicates().copy()

    # Normalize text values
    text_cols = ["Gender", "Product Category", "Product Name", "Payment Method", "City"]
    for col in text_cols:
        df[col] = df[col].astype("string").str.strip()

    df["Product Category"] = df["Product Category"].str.title()
    df["Gender"] = df["Gender"].str.title()
    df["Payment Method"] = df["Payment Method"].str.upper().replace({
        "UPI": "UPI", "CREDIT CARD": "Credit Card", "DEBIT CARD": "Debit Card",
        "NET BANKING": "Net Banking", "CASH": "Cash"
    })
    # Restore consistent display casing for payment values
    df["Payment Method"] = df["Payment Method"].replace({
        "CREDIT CARD": "Credit Card", "DEBIT CARD": "Debit Card",
        "NET BANKING": "Net Banking"
    })
    df["City"] = df["City"].str.title()

    # Convert columns to appropriate data types
    df["Order Date"] = pd.to_datetime(df["Order Date"], errors="coerce")
    numeric_cols = ["Age", "Quantity", "Unit Price", "Total Sales"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Invalid values become missing before imputation
    df.loc[~df["Age"].between(18, 100), "Age"] = np.nan
    df.loc[df["Quantity"] <= 0, "Quantity"] = np.nan
    df.loc[df["Unit Price"] <= 0, "Unit Price"] = np.nan
    df.loc[df["Order Date"].isna(), "Order Date"] = pd.NaT

    # Fill missing values with robust or most-frequent values
    df["Age"] = df["Age"].fillna(df["Age"].median()).round().astype(int)
    df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median()).round().astype(int)
    df["Unit Price"] = df["Unit Price"].fillna(df["Unit Price"].median())
    for col in ["Gender", "Product Category", "Product Name", "Payment Method", "City"]:
        mode = df[col].mode(dropna=True)
        df[col] = df[col].fillna(mode.iloc[0] if not mode.empty else "Unknown")

    # Recalculate sales from quantity and unit price to maintain consistency
    df["Total Sales"] = df["Quantity"] * df["Unit Price"]
    df = df.dropna(subset=["Order Date"])
    df["Order Date"] = df["Order Date"].dt.strftime("%Y-%m-%d")
    df["Quantity"] = df["Quantity"].astype(int)
    df["Age"] = df["Age"].astype(int)
    df["Unit Price"] = df["Unit Price"].round(2)
    df["Total Sales"] = df["Total Sales"].round(2)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)

    report = [
        "DATA QUALITY REPORT",
        "===================",
        f"Rows before cleaning: {original_rows}",
        f"Rows after cleaning: {len(df)}",
        f"Duplicate rows removed: {duplicates_removed}",
        f"Missing cells before cleaning: {missing_before}",
        f"Missing cells after cleaning: {int(df.isna().sum().sum())}",
        "Invalid ages: replaced with median after validation (valid range 18-100).",
        "Invalid quantities/prices: replaced with median.",
        "Total Sales: recalculated as Quantity x Unit Price.",
        "Text categories: trimmed and standardized."
    ]
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\\n".join(report), encoding="utf-8")
    return df

if __name__ == "__main__":
    result = clean_data()
    print(f"Cleaning complete. Saved {len(result)} rows to {CLEAN_PATH}")
