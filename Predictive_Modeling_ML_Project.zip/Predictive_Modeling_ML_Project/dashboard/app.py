"""Simple Streamlit interface for placement prediction and model metrics."""
from pathlib import Path
import json
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "cleaned_student_placement.csv"
METRICS = ROOT / "output" / "reports" / "model_metrics.json"

st.set_page_config(page_title="Predictive Modeling Dashboard", page_icon="🤖", layout="wide")
st.title("🤖 Student Placement Prediction")
st.write("A supervised machine learning project that predicts placement outcomes and estimates salary packages.")

if not DATA.exists() or not METRICS.exists():
    st.warning("Project outputs are not ready. Run `python main.py` from the project root first.")
    st.stop()

df = pd.read_csv(DATA)
results = json.loads(METRICS.read_text(encoding="utf-8"))
a, b, c = st.columns(3)
a.metric("Dataset Records", f"{len(df):,}")
b.metric("Placement Rate", f"{df['Placed'].mean()*100:.1f}%")
c.metric("Best Classifier", results["best_classification_model"])

st.subheader("Classification Model Comparison")
metrics_df = pd.DataFrame(results["classification"]).T
st.dataframe(metrics_df.style.format("{:.3f}"), use_container_width=True)

st.subheader("Regression Model Comparison (Package Prediction)")
reg_df = pd.DataFrame(results["regression"]).T
st.dataframe(reg_df.style.format("{:.3f}"), use_container_width=True)

for title, filename in [
    ("Confusion Matrix", "confusion_matrix.png"),
    ("ROC Curves", "roc_curves.png"),
    ("Classification Accuracy", "classification_accuracy.png")
]:
    image_path = ROOT / "output" / "charts" / filename
    if image_path.exists():
        st.subheader(title)
        st.image(str(image_path), use_container_width=True)

st.subheader("Try a Student Profile")
with st.form("prediction_form"):
    cols = st.columns(3)
    cgpa = cols[0].slider("CGPA", 0.0, 10.0, 7.5, 0.1)
    aptitude = cols[1].slider("Aptitude Score", 0, 100, 65)
    coding = cols[2].slider("Coding Score", 0, 100, 60)
    communication = cols[0].slider("Communication Score", 0, 100, 70)
    internships = cols[1].number_input("Internships", 0, 10, 1)
    projects = cols[2].number_input("Projects", 0, 20, 2)
    attendance = st.slider("Attendance (%)", 0, 100, 85)
    submitted = st.form_submit_button("Show sample prediction")
if submitted:
    st.info("This demo dashboard displays model evaluation and sample student inputs. For live predictions, load the saved trained pipeline in a future enhancement.")
