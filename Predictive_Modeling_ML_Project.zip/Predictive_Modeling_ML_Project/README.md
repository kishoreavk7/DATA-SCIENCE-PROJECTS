# Predictive Modeling Using Machine Learning

A beginner-friendly supervised machine learning project that predicts student placement outcomes and estimates salary packages using academic and skill-related data.

## Project objectives
- Prepare and clean a structured dataset.
- Train supervised classification algorithms.
- Evaluate model performance on unseen test data.
- Visualize confusion matrix, ROC curves, and model comparison.
- Explore regression models for package prediction.

## Algorithms
**Classification:** Logistic Regression, Decision Tree, Random Forest.  
**Regression:** Linear Regression, Random Forest Regressor.

## Dataset
The included synthetic dataset contains student CGPA, aptitude, coding, communication, internships, projects, attendance, placement status, and package in LPA. It is generated for educational demonstration and does not contain real student data.

## Project structure
```text
Predictive_Modeling_ML_Project/
├── data/
│   ├── raw_student_placement.csv
│   └── cleaned_student_placement.csv
├── src/
│   ├── data_preprocessing.py
│   └── train_models.py
├── dashboard/
│   └── app.py
├── output/
│   ├── charts/
│   └── reports/
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Setup
Open the project folder in VS Code and install dependencies:
```bash
pip install -r requirements.txt
```

## Run the project
From the project root:
```bash
python main.py
```

The workflow cleans the dataset, trains the models, evaluates them, and saves reports and charts.

## Run the dashboard
```bash
streamlit run dashboard/app.py
```

## Evaluation
Classification models are compared using accuracy, precision, recall, F1-score, and ROC-AUC. A confusion matrix is generated for the classifier with the best F1-score. Regression models are evaluated using MAE, RMSE, and R².

## Important note
This is a synthetic educational dataset. Model scores demonstrate the workflow only and should not be interpreted as real-world hiring predictions. The dashboard is for viewing evaluation results; live prediction from a saved model can be added as a future improvement.
