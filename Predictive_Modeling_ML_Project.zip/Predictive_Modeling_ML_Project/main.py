"""Run preprocessing, model training, and evaluation."""
from src.data_preprocessing import preprocess_data
from src.train_models import train_and_evaluate

def main():
    print("1/2 Cleaning dataset...")
    preprocess_data()
    print("2/2 Training and evaluating models...")
    results = train_and_evaluate()
    print("\nPROJECT COMPLETED")
    print("Best classification model:", results["best_classification_model"])
    print("Reports: output/reports/")
    print("Charts: output/charts/")

if __name__ == "__main__":
    main()
