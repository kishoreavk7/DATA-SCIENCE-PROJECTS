"""Train classification and regression models and save evaluation outputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, ConfusionMatrixDisplay,
                             roc_curve, mean_absolute_error, mean_squared_error, r2_score)
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "cleaned_student_placement.csv"
CHARTS = ROOT / "output" / "charts"
REPORTS = ROOT / "output" / "reports"
FEATURES = ["CGPA", "Aptitude_Score", "Coding_Score", "Communication_Score",
            "Internships", "Projects", "Attendance_Percent"]

def train_and_evaluate():
    CHARTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA)
    X = df[FEATURES]
    y = df["Placed"].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    classifiers = {
        "Logistic Regression": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=1000, random_state=42))
        ]),
        "Decision Tree": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", DecisionTreeClassifier(max_depth=5, random_state=42))
        ]),
        "Random Forest": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(n_estimators=250, max_depth=8, random_state=42))
        ])
    }

    metrics = {}
    probabilities = {}
    for name, model in classifiers.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        score = model.predict_proba(X_test)[:, 1]
        metrics[name] = {
            "accuracy": float(accuracy_score(y_test, pred)),
            "precision": float(precision_score(y_test, pred, zero_division=0)),
            "recall": float(recall_score(y_test, pred, zero_division=0)),
            "f1_score": float(f1_score(y_test, pred, zero_division=0)),
            "roc_auc": float(roc_auc_score(y_test, score))
        }
        probabilities[name] = (pred, score)

    best_name = max(metrics, key=lambda k: metrics[k]["f1_score"])
    best_model = classifiers[best_name]
    best_pred, best_prob = probabilities[best_name]

    # Confusion matrix for best F1 model
    cm = confusion_matrix(y_test, best_pred)
    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay(cm, display_labels=["Not Placed", "Placed"]).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"Confusion Matrix - {best_name}")
    fig.tight_layout()
    fig.savefig(CHARTS / "confusion_matrix.png", dpi=150)
    plt.close(fig)

    # ROC curves for all classifiers
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, (_, score) in probabilities.items():
        fpr, tpr, _ = roc_curve(y_test, score)
        ax.plot(fpr, tpr, label=f"{name} (AUC={metrics[name]['roc_auc']:.2f})")
    ax.plot([0, 1], [0, 1], linestyle="--", label="Random baseline")
    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve Comparison"); ax.legend()
    fig.tight_layout()
    fig.savefig(CHARTS / "roc_curves.png", dpi=150)
    plt.close(fig)

    # Compare classification accuracy
    fig, ax = plt.subplots(figsize=(8, 4))
    pd.Series({k:v["accuracy"] for k,v in metrics.items()}).sort_values().plot(kind="barh", ax=ax)
    ax.set_xlim(0, 1); ax.set_xlabel("Accuracy"); ax.set_title("Classification Model Accuracy")
    fig.tight_layout(); fig.savefig(CHARTS / "classification_accuracy.png", dpi=150); plt.close(fig)

    # Regression: predict package for placed students only
    placed_df = df[df["Placed"] == 1].copy()
    Xr = placed_df[FEATURES]
    yr = placed_df["Package_LPA"]
    Xr_train, Xr_test, yr_train, yr_test = train_test_split(Xr, yr, test_size=0.2, random_state=42)
    regressors = {
        "Linear Regression": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LinearRegression())
        ]),
        "Random Forest Regressor": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestRegressor(n_estimators=200, max_depth=8, random_state=42))
        ])
    }
    regression_metrics = {}
    for name, model in regressors.items():
        model.fit(Xr_train, yr_train)
        pred = model.predict(Xr_test)
        regression_metrics[name] = {
            "MAE": float(mean_absolute_error(yr_test, pred)),
            "RMSE": float(np.sqrt(mean_squared_error(yr_test, pred))),
            "R2": float(r2_score(yr_test, pred))
        }

    results = {"classification": metrics, "best_classification_model": best_name,
               "regression": regression_metrics, "test_rows_classification": int(len(y_test)),
               "test_rows_regression": int(len(yr_test))}
    (REPORTS / "model_metrics.json").write_text(json.dumps(results, indent=2), encoding="utf-8")

    lines = ["MODEL EVALUATION REPORT", "=======================",
             f"Best classification model by F1 score: {best_name}", "",
             "CLASSIFICATION METRICS"]
    for name, values in metrics.items():
        lines.append(name + ": " + ", ".join(f"{k}={v:.3f}" for k,v in values.items()))
    lines += ["", "REGRESSION METRICS (placed students only)"]
    for name, values in regression_metrics.items():
        lines.append(name + ": " + ", ".join(f"{k}={v:.3f}" for k,v in values.items()))
    (REPORTS / "model_evaluation_report.txt").write_text("\n".join(lines), encoding="utf-8")
    return results

if __name__ == "__main__":
    result = train_and_evaluate()
    print("Training complete. Best classifier:", result["best_classification_model"])
