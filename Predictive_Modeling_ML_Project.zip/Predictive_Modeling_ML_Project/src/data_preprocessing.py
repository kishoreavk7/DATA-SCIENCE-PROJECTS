"""Load and clean the student placement dataset."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw_student_placement.csv"
CLEAN = ROOT / "data" / "cleaned_student_placement.csv"

def preprocess_data():
    data = pd.read_csv(RAW)
    before = len(data)
    duplicates = int(data.duplicated().sum())
    data = data.drop_duplicates().copy()
    numeric = ["CGPA", "Aptitude_Score", "Coding_Score", "Communication_Score",
               "Internships", "Projects", "Attendance_Percent", "Placed", "Package_LPA"]
    for col in numeric:
        data[col] = pd.to_numeric(data[col], errors="coerce")
        data[col] = data[col].fillna(data[col].median())
    # Keep values within sensible ranges
    data["CGPA"] = data["CGPA"].clip(0, 10)
    for col in ["Aptitude_Score", "Coding_Score", "Communication_Score", "Attendance_Percent"]:
        data[col] = data[col].clip(0, 100)
    data["Internships"] = data["Internships"].clip(0, 10).round().astype(int)
    data["Projects"] = data["Projects"].clip(0, 20).round().astype(int)
    data["Placed"] = data["Placed"].clip(0, 1).round().astype(int)
    data["Package_LPA"] = data["Package_LPA"].clip(lower=0)
    CLEAN.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(CLEAN, index=False)
    report = (
        "DATA PREPROCESSING REPORT\n"
        "=========================\n"
        f"Rows before cleaning: {before}\n"
        f"Rows after cleaning: {len(data)}\n"
        f"Duplicate rows removed: {duplicates}\n"
        f"Missing cells after cleaning: {int(data.isna().sum().sum())}\n"
        "Numeric missing values: filled using column median.\n"
        "Scores and percentages: clipped to valid 0-100 ranges; CGPA clipped to 0-10.\n"
        "Package_LPA: negative values clipped to zero.\n"
    )
    (ROOT / "output" / "reports" / "preprocessing_report.txt").write_text(report, encoding="utf-8")
    return data

if __name__ == "__main__":
    cleaned = preprocess_data()
    print(f"Preprocessing complete: {len(cleaned)} rows saved.")
